The resources distributed with this file are from the book entitled
"Minimal Perl: for UNIX and Linux People", by Tim Maher, published
by Manning Publications Co.

For additional information on this book and related topics, see:
* the author's web-site for the book
    http://MinimalPerl.com   

* the publisher's web-site for the book
    http://Manning.com/maher  

* the web-site for the author's UNIX/Linux/Perl training business
    http://TeachMePerl.com 

                                         (Version 1.0, 10/09/06)
