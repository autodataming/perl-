
Mojolicious lite and bootstrap based simple cms
  
  Requirements
  
	- perl 5.10 to higher
	- Mojolicious (4.62, Top Hat)
  
  Install
  
	-  $ curl -L https://cpanmin.us | perl - --sudo App::cpanminus.
	-  $ cpanm ORLite.pm
	-  $ cpanm Mojolicious
	-  $ git clone https://github.com/ovntatar/MicroCMS.git
	-  $ cd MicroCMS
	-  $ morbo MicroCMS.pl
  Login

	- access:	http://127.0.0.1:3000
	- email: 	admin@myproject.com
	- password:	admin
